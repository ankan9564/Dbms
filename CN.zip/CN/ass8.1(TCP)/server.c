#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void handle_client(int client_socket) {
char buffer[BUFFER_SIZE];
int bytes_read;

while ((bytes_read = recv(client_socket, buffer, BUFFER_SIZE, 0)) > 0) {
buffer[bytes_read] = '\0';
printf("Received: %s", buffer);
send(client_socket, buffer, bytes_read, 0);
}

close(client_socket);
printf("Client disconnected.\n");
}

int main() {

int server_fd, client_fd;
struct sockaddr_in server_addr, client_addr;
socklen_t addr_len = sizeof(client_addr);

server_fd = socket(AF_INET, SOCK_STREAM, 0);
if (server_fd == 0) {
perror("Socket failed");
exit(EXIT_FAILURE);
}

server_addr.sin_family = AF_INET;
server_addr.sin_addr.s_addr = INADDR_ANY;
server_addr.sin_port = htons(PORT);

bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr));
listen(server_fd, 5);

printf("Server listening on port %d...\n", PORT);

while (1) {
client_fd = accept(server_fd, (struct sockaddr*)&client_addr, &addr_len);
if (client_fd < 0) {
perror("Accept failed");
continue;
}

printf("New client connected.\n");

if (fork() == 0) {
// Child process
close(server_fd);
handle_client(client_fd);
exit(0);

} else {
// Parent process
close(client_fd);
}
}

close(server_fd);
return 0;
}
