#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX 1024

int main() {
int sockfd;
struct sockaddr_in servaddr;
int window_size = 4;
int total_frames = 10;
int ack, i;

sockfd = socket(AF_INET, SOCK_STREAM, 0);
if (sockfd == -1) {
perror("Socket creation failed");
exit(0);
}

servaddr.sin_family = AF_INET;
servaddr.sin_port = htons(PORT);
servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));

printf("Sliding Window Protocol Simulation (Sender)\n");
printf("Total frames to send: %d\n", total_frames);
printf("Window size: %d\n", window_size);

for (i = 1; i <= total_frames;) {
int j;
for (j = 0; j < window_size && (i + j) <= total_frames; j++) {
printf("Sending frame %d\n", i + j);
send(sockfd, &i, sizeof(i), 0);
sleep(1); // simulate delay
}

// Wait for acknowledgment
recv(sockfd, &ack, sizeof(ack), 0);
printf("Acknowledgment received for frame %d\n", ack);

i = ack + 1; // Slide the window

}

close(sockfd);
return 0;
}
