#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX 1024

int main() {
int sockfd, connfd;
struct sockaddr_in servaddr, cli;
int frame;

sockfd = socket(AF_INET, SOCK_STREAM, 0);
if (sockfd == -1) {
perror("Socket creation failed");
exit(0);
}

servaddr.sin_family = AF_INET;
servaddr.sin_addr.s_addr = INADDR_ANY;
servaddr.sin_port = htons(PORT);

bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));
listen(sockfd, 5);

socklen_t len = sizeof(cli);
connfd = accept(sockfd, (struct sockaddr*)&cli, &len);
if (connfd < 0) {
perror("Server accept failed");
exit(0);
}

printf("Sliding Window Protocol Simulation (Receiver)\n");

int last_ack = 0;
while (recv(connfd, &frame, sizeof(frame), 0)) {
printf("Received frame %d\n", frame);
last_ack = frame; // Always acknowledge the last received frame
send(connfd, &last_ack, sizeof(last_ack), 0);
sleep(1); // simulate processing
}

close(connfd);
close(sockfd);
return 0;
}
