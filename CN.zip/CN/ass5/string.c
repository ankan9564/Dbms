#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
int main() {
int pipe1[2]; // Parent to Child
int pipe2[2]; // Child to Parent
// Create pipes
if (pipe(pipe1) == -1 || pipe(pipe2) == -1) {
fprintf(stderr, "Error creating pipes: %s\n", strerror(errno));
return 1;
}
int id = fork(); // Create a child process
if (id == -1) {
fprintf(stderr, "Error forking: %s\n", strerror(errno));
return 1;
}
if (id == 0) {
// Child process code
close(pipe1[1]); // Close write end of pipe1
close(pipe2[0]); // Close read end of pipe2
char buffer[100];

// Read message from parent
read(pipe1[0], buffer, sizeof(buffer));
printf("Child received: %s\n", buffer);
// Send response to parent
const char *response = "Hello from Child!";
write(pipe2[1], response, strlen(response) + 1); // +1 for null terminator
close(pipe1[0]); // Close read end of pipe1
close(pipe2[1]); // Close write end of pipe2
} else {
// Parent process code
close(pipe1[0]); // Close read end of pipe1
close(pipe2[1]); // Close write end of pipe2
const char *message = "Hello from Parent!";
// Send message to child
write(pipe1[1], message, strlen(message) + 1); // +1 for null terminator
char buffer[100];
// Read response from child
read(pipe2[0], buffer, sizeof(buffer));
printf("Parent received: %s\n", buffer);
close(pipe1[1]); // Close write end of pipe1
close(pipe2[0]); // Close read end of pipe2
wait(NULL); // Wait for the child process to finish
}
return 0;
}
