#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>

int main(int argc, char* argv[]) {
    int fd[2];
    // fd[0] - read end
    // fd[1] - write end

    // Create a pipe
    if (pipe(fd) == -1) {
        perror("pipe"); // Use perror for error messages
        return 1;
    }

    int id = fork(); // Create a child process
    if (id == -1) {
        perror("fork"); // Use perror for error messages
        return 2;
    }

    if (id == 0) {
        // Child process code
        close(fd[0]); // Child will not read from the pipe

        int x = 5; // Example value to write into the pipe

        // Writing the value of x to the pipe and checking for errors
        if (write(fd[1], &x, sizeof(int)) == -1) {
            perror("write"); // Use perror for error messages
            exit(1);
        }

        close(fd[1]); // Close the write end after writing
    } else {
        // Parent process code
        close(fd[1]); // Parent will not write to the pipe

        int y;

        // Reading from the pipe and checking for errors
        if (read(fd[0], &y, sizeof(int)) == -1) {
            perror("read"); // Use perror for error messages
            exit(1);
        }

        close(fd[0]); // Close the read end after reading

        printf("Parent received: %d\n", y); // Print the value received from the child

        wait(NULL); // Wait for the child process to finish
    }

    return 0;
}

