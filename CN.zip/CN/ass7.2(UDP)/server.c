#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // For close()
#include <arpa/inet.h> // For socket functions
#define PORT 65432
#define BUFFER_SIZE 1024
int main() {
int server_fd;
struct sockaddr_in server_addr, client_addr;
char buffer[BUFFER_SIZE];
socklen_t addr_len = sizeof(client_addr);
// Create the UDP socket
if ((server_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
perror("Socket creation failed");
exit(EXIT_FAILURE);
}
// Configure the server address
server_addr.sin_family = AF_INET; // IPv4
server_addr.sin_addr.s_addr = INADDR_ANY; // Accept connections on any IP
server_addr.sin_port = htons(PORT); // Convert port to network byte order
// Bind the socket to the specified address and port
if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
perror("Bind failed");
close(server_fd);
exit(EXIT_FAILURE);
}

printf("UDP Echo Server listening on port %d...\n", PORT);
// Iteratively handle incoming messages
while (1) {
// Clear the buffer and receive a message from the client
memset(buffer, 0, BUFFER_SIZE);
int bytes_received = recvfrom(server_fd, buffer, BUFFER_SIZE, 0,
(struct sockaddr *)&client_addr, &addr_len);
if (bytes_received > 0) {
printf("Received from client %s:%d - %s\n",
inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port), buffer);
// Echo the message back to the client
sendto(server_fd, buffer, bytes_received, 0,
(struct sockaddr *)&client_addr, addr_len);
printf("Echoed back to client.\n");
} else {
printf("Failed to receive message.\n");
}
}
// Close the socket (not reached in this example)
close(server_fd);
return 0;
}
