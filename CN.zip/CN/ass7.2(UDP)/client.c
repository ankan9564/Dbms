#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // For close()
#include <arpa/inet.h> // For socket functions
#define PORT 65432
#define BUFFER_SIZE 1024
int main() {
int sock;
struct sockaddr_in server_addr;
char message[BUFFER_SIZE], buffer[BUFFER_SIZE];
socklen_t addr_len = sizeof(server_addr);
// Create the UDP socket
if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
perror("Socket creation failed");
return -1;
}
// Configure the server address
server_addr.sin_family = AF_INET;
server_addr.sin_port = htons(PORT);

// Convert IP address from text to binary
if (inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr) <= 0) {
printf("Invalid address or address not supported\n");
return -1;
}
// Get the message from the user
printf("Enter message to send: ");
fgets(message, sizeof(message), stdin);
// Send the message to the server
sendto(sock, message, strlen(message), 0,
(struct sockaddr *)&server_addr, addr_len);
// Receive the echoed message from the server
int bytes_received = recvfrom(sock, buffer, BUFFER_SIZE, 0,
(struct sockaddr *)&server_addr, &addr_len);
buffer[bytes_received] = '\0'; // Null-terminate the received string
printf("Echo from server: %s\n", buffer);
// Close the socket
close(sock);
return 0;
}
