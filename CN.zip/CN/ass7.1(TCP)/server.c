#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // For close()
#include <arpa/inet.h> // For socket functions
#define PORT 65432
#define BUFFER_SIZE 1024
int main() {
int server_fd, new_socket;
struct sockaddr_in address;
int addrlen = sizeof(address);
char buffer[BUFFER_SIZE];
// Create the socket (IPv4, TCP)
if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
perror("Socket creation failed");
exit(EXIT_FAILURE);
}
// Configure the server address
address.sin_family = AF_INET; // IPv4
address.sin_addr.s_addr = INADDR_ANY; // Accept connections on any IP
address.sin_port = htons(PORT); // Convert port to network byte order
// Bind the socket to the address and port
if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
perror("Bind failed");
close(server_fd);
exit(EXIT_FAILURE);
}
// Listen for incoming connections (max queue size = 3)
if (listen(server_fd, 3) < 0) {
perror("Listen failed");
close(server_fd);
exit(EXIT_FAILURE);
}

printf("Echo server listening on port %d...\n", PORT);
// Iteratively accept and handle client connections
while (1) {
// Accept a client connection
if ((new_socket = accept(server_fd, (struct sockaddr *)&address,
(socklen_t *)&addrlen)) < 0) {
perror("Accept failed");
continue; // If accept fails, try the next connection
}
printf("Connected to client: %s:%d\n",
inet_ntoa(address.sin_addr), ntohs(address.sin_port));
// Clear the buffer and receive the client's message
memset(buffer, 0, BUFFER_SIZE);
int bytes_received = read(new_socket, buffer, BUFFER_SIZE);
if (bytes_received > 0) {
printf("Received from client: %s\n", buffer);
// Echo the message back to the client
send(new_socket, buffer, bytes_received, 0);
printf("Echoed back to client.\n");
} else {
printf("No data received from client.\n");
}
// Close the client socket
close(new_socket);
printf("Connection with client closed.\n");
}
// Close the server socket (never reached in this example)
close(server_fd);
return 0;
}
